Please consider the following before submitting a pull request:

Guidelines for contributing: https://github.com/pure-css/pure/blob/master/CONTRIBUTING.md

Example of changes on an interactive website such as the following:

- http://jsbin.com/
- http://jsfiddle.net/
- http://codepen.io/pen/
